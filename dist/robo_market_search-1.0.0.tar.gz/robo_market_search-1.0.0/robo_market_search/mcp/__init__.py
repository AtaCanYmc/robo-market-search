# MCP package initialization
